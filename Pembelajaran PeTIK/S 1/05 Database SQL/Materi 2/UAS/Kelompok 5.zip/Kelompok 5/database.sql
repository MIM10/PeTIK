-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: dbkeuangan
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `barang`
--

DROP TABLE IF EXISTS `barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `min_stok` int(11) DEFAULT NULL,
  `harga_beli` double DEFAULT NULL,
  `harga_jual` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barang`
--

LOCK TABLES `barang` WRITE;
/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
INSERT INTO `barang` VALUES (1,'Monitor',20,12,1250000,1750000),(2,'CPU',50,12,4500000,4999000),(3,'Mouse Pad Classic',80,48,5500,6500),(4,'Mouse Classic',61,24,45000,60000),(5,'Keyboard Gaming',21,12,250000,295000),(6,'Mouse Gaming',25,12,100000,143000),(7,'Keyboard Classic',34,24,80000,110000),(8,'Flash Disk 8 GB',48,12,90000,99000),(9,'Hard Disk 1 TB',84,6,780000,800000),(10,'Earphone Gaming',50,20,100000,120000);
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER before_barang_update
BEFORE UPDATE ON barang
FOR EACH ROW
BEGIN
INSERT INTO log_harga_barang
SET nama = OLD.nama,
harga_baru = NEW.harga_beli,
harga_lama = OLD.harga_beli,
waktu_pembuatan = NOW();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `beli`
--

DROP TABLE IF EXISTS `beli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `beli` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(45) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `id_suplier` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idbarang` (`id_barang`),
  KEY `idsuplier` (`id_suplier`),
  CONSTRAINT `beli_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `beli_ibfk_2` FOREIGN KEY (`id_suplier`) REFERENCES `suplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `beli`
--

LOCK TABLES `beli` WRITE;
/*!40000 ALTER TABLE `beli` DISABLE KEYS */;
INSERT INTO `beli` VALUES (1,'2022-06-01',1,1),(2,'2022-06-02',3,10),(3,'2022-06-05',2,8),(4,'2022-06-08',4,7),(5,'2022-06-11',5,9),(6,'2022-06-14',6,5),(7,'2022-06-17',7,6),(8,'2022-06-18',8,2),(9,'2022-06-25',9,3),(10,'2022-06-30',10,4);
/*!40000 ALTER TABLE `beli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jual`
--

DROP TABLE IF EXISTS `jual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tgl` varchar(45) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `id_konsumen` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idbarang` (`id_barang`),
  KEY `idkonsumen` (`id_konsumen`),
  CONSTRAINT `jual_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `jual_ibfk_2` FOREIGN KEY (`id_konsumen`) REFERENCES `konsumen` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jual`
--

LOCK TABLES `jual` WRITE;
/*!40000 ALTER TABLE `jual` DISABLE KEYS */;
INSERT INTO `jual` VALUES (1,'2022-09-12',1,1),(2,'2022-09-13',3,10),(3,'2022-09-15',2,8),(4,'2022-09-17',4,7),(5,'2022-09-19',5,9),(6,'2022-09-21',6,5),(7,'2022-09-22',7,6),(8,'2022-09-25',8,2),(9,'2022-09-28',9,3),(10,'2022-09-29',10,4);
/*!40000 ALTER TABLE `jual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konsumen`
--

DROP TABLE IF EXISTS `konsumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `konsumen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) DEFAULT NULL,
  `alamat` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `no_tlp` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konsumen`
--

LOCK TABLES `konsumen` WRITE;
/*!40000 ALTER TABLE `konsumen` DISABLE KEYS */;
INSERT INTO `konsumen` VALUES (1,'Adis Saputra','Surabaya','adis@gmail.com','081246589635'),(2,'Gouju Satoru','Tokyo','satoru@gmail.com','082653946278'),(3,'Zufar Rahmat','Probolinggo','zufar@yahoo.com','083264598745'),(4,'Ipang Doni','Malang','doni@gmail.com','085774695312'),(5,'Ajeng Putri','Jombang','putri@yahoo.com','085623641542'),(6,'Alex Owiboy','Makassar','owi@yahoo.com','085786990834'),(7,'Xiao Megachan','Dumai','megachan@gmail.com','081255311986'),(8,'Zhiang Puan','Jakarta','zpuan@yahoo.com','085600967855'),(9,'Narudin Syarif','Sidoarjo','narudin@yahoo.com','085782855125'),(10,'Nurmala Dewi','Aceh','nurmala@gmail.com','081277549900');
/*!40000 ALTER TABLE `konsumen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_harga_barang`
--

DROP TABLE IF EXISTS `log_harga_barang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_harga_barang` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) DEFAULT NULL,
  `harga_lama` int(11) DEFAULT NULL,
  `harga_baru` int(11) DEFAULT NULL,
  `waktu_pembuatan` datetime DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_harga_barang`
--

LOCK TABLES `log_harga_barang` WRITE;
/*!40000 ALTER TABLE `log_harga_barang` DISABLE KEYS */;
INSERT INTO `log_harga_barang` VALUES (1,'Mouse Pad Classic',4000,5500,'2022-10-18 08:51:43');
/*!40000 ALTER TABLE `log_harga_barang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suplier`
--

DROP TABLE IF EXISTS `suplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(45) DEFAULT NULL,
  `alamat` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `no_tlp` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suplier`
--

LOCK TABLES `suplier` WRITE;
/*!40000 ALTER TABLE `suplier` DISABLE KEYS */;
INSERT INTO `suplier` VALUES (1,'Halil Hadid','Jl.Pahlawan 9','halil@gmail.com','086694523144'),(2,'Melike Sahin','Jl.Pos 3','melike@gmail.com','081276839201'),(3,'Altan Duzyatan','Jl.Kamurang 7','altan@gmail.com','084967513542'),(4,'Rumeysa Yildiz','Jl.Mayor Oking 4','yildiz@gmail.com','081276839201'),(5,'Mehmet Bozdag','Jl.Sabilillah 1','bozdag@gmail.com','085425698569'),(6,'Nur Syakira','Jl.Diploma 12','syakira@yahoo.com','085966425509'),(7,'Aditia Reka','Jl.Pendidikan 15','adit@yahoo.com','081299807654'),(8,'Riska Ramadani','Jl.Balai 20','riska@yahoo.com','081478665321'),(9,'Ahmad Dian','Jl.Mangga 2','ahmad@yahoo.com','081298007654'),(10,'Ilham Ramdan','Jl.Sudirman 15','ilham@yahoo.com','085799065432');
/*!40000 ALTER TABLE `suplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_barang_konsumen`
--

DROP TABLE IF EXISTS `vw_barang_konsumen`;
/*!50001 DROP VIEW IF EXISTS `vw_barang_konsumen`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vw_barang_konsumen` (
  `Id_Konsumen` tinyint NOT NULL,
  `Nama_Konsumen` tinyint NOT NULL,
  `Alamat_Konsumen` tinyint NOT NULL,
  `Id_Jual` tinyint NOT NULL,
  `Nama_Barang` tinyint NOT NULL,
  `Stok_Barang` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_barang_konsumen`
--

/*!50001 DROP TABLE IF EXISTS `vw_barang_konsumen`*/;
/*!50001 DROP VIEW IF EXISTS `vw_barang_konsumen`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_barang_konsumen` AS select `konsumen`.`id` AS `Id_Konsumen`,`konsumen`.`nama` AS `Nama_Konsumen`,`konsumen`.`alamat` AS `Alamat_Konsumen`,`jual`.`id` AS `Id_Jual`,`barang`.`nama` AS `Nama_Barang`,`barang`.`stok` AS `Stok_Barang` from ((`konsumen` join `jual` on(`konsumen`.`id` = `jual`.`id_konsumen`)) join `barang` on(`jual`.`id_barang` = `barang`.`id`)) group by `konsumen`.`id`,`konsumen`.`nama` order by `konsumen`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-18 10:10:56
