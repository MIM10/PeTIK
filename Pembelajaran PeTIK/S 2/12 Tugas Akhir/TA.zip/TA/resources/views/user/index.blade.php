@extends('layouts.main')

@section('title', 'HNI Catalog')
@section('container')
    {{-- section --}}
    
    <div class="flex flex-wrap mt-10 hpK:mx-3 hpG:mx-5 tablet:mx-10 laptop:mx-32 desktop:mx-60 justify-center bg-white gap-3">
        {{-- card --}}
        @foreach ($ar_produk as $i)
            <div onclick="toggleModal('{{ $i->id }}')" class="flex flex-col py-3 rounded hover:bg-gray-200 duration-300 cursor-pointer shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] bg-white ">
                <div class="mb-2 mx-3 rounded shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] hp:w-28 ">
                    <img src="{{ asset($i->foto) }}" alt="{{ $i->nama }}" class="min-h-[100px] max-h-[150px] my-2">
                </div>
                <div class="flex flex-col mx-3">
                    <div class="mb-10">
                        <p class="text-[13px] ">{{ $i->nama }}</p>
                    </div>
                    <div class="flex flex-row justify-between">
                        <p class="text-[12px] font-extralight text-gray-500">Rp. {{ $i->harga }}</p>
                        <p class="text-[12px] font-extralight text-gray-500">Stok : {{ $i->stok }}</p>
                    </div>
                </div>
            </div>

            {{-- modal --}}
            <div id="modal{{ $i->id }}" class="hidden fixed inset-0 flex items-center justify-center z-50">
                {{-- <div class="absolute inset-0 bg-black opacity-50"></div> --}}
                <div class="flex flex-col justify-content-center bg-white hpK:w-72 shadow-[0px_0px_3px_3px_rgba(0,0,0,0.10)] rounded-lg p-6 max-w-md">
                    <div class="flex">
                        {{-- class="text-3xl cursor-pointer ml-auto mx-2 nav:hidden block --}}
                        <div class="text-2xl items-center cursor-pointer mr-2" onclick="toggleModal('{{ $i->id }}')">
                            <ion-icon class="hover:bg-gray-200 duration-200" name="close" id="menuBtn"></ion-icon>
                        </div>
                        <h2 class="text-xl flex text-center font-semibold mt-[-1px] mb-4">Product Details</h2>
                    </div>
                    <div class="mb-5 flex rounded justify-center shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] hp:w-28 ">
                        <img src="{{ asset($i->foto) }}" alt="{{ $i->nama }}" class="min-h-[100px] max-h-[150px] my-7">
                    </div>
                    <div class="max-w-lg mx-auto h-80 overflow-y-scroll">
                        <p class="mb-1 font-semibold">{{ $i->nama }}</p>
                        <div class="flex text-[12px] mb-5 font-extralight text-gray-500">
                            <p class="mr-2">Rp. {{ $i->harga }}</p>
                            <p class="ml-2">Stok : {{ $i->stok }}</p>
                        </div>
                        <div>
                            <p class="text-sm font-semibold">Kegunaan</p>
                            <p class="text-[12px] mb-5 font-normal">{{ $i->kegunaan }}</p>
                            <p class="text-sm font-semibold">Komposisi</p>
                            <p class="text-[12px] mb-5 font-normal">{{ $i->komposisi }}</p>
                            <p class="text-sm font-semibold">Aturan Pakai</p>
                            <p class="text-[12px] mb-2 font-normal">{{ $i->aturan_pakai }}</p>
                        </div>
                    </div>
                    <!-- Add more details here if needed -->
                    <a href="https://api.whatsapp.com/send?phone=+6285772396815&text=Assalamualaikum%20saya%20mau%20pesan%20%3A%0A*{{ $i->nama }}*%0ANama%20%3A%20...%0AJumlah%20%3A%20...%0AAlamat%20%3A%20..." target="_blank">
                        <div class="bg-gray-300 hover:bg-gray-400 duration-300 px-4 py-2 rounded-lg mt-4 cursor-pointer text-center">
                            Buy 
                        </div>
                    </a>
                </div>
            </div>
        @endforeach
    </div>
@endsection
