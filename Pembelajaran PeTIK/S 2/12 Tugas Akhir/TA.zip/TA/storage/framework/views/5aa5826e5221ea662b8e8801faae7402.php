<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>

<body>
    
    <nav class="p-3 px-5 bg-white shadow nav:flex nav:items-center nav:justify-between">
        <div class="flex  items-center">
            <span <?php echo e(url('url', [])); ?> class="text-2xl font-semibold cursor-pointer">
                <img class="h-10 inline mr-4" src="<?php echo e(asset('/img/Logo-HNI.png')); ?>" alt="Logo">
                HNI Catalog
            </span>

            <span class="text-3xl cursor-pointer ml-auto mx-2 nav:hidden block">
                <ion-icon name="menu" id="menuBtn"></ion-icon>
            </span>
        </div>

        <ul id="menuItem"
            class="nav:flex nav:items-center z-[0] nav:z-auto nav:static absolute bg-white w-full left-0 nav:w-auto nav:py-0 py-4 nav:pl-0 pl-7 nav:opacity-100 opacity-0 top-[-400px] transition-all ease-in duration-500">
            <li class="mx-2 my-5 nav:my-0">
                <a href="/" class="text-xl duration-500">
                    <p class="px-2 py-1 rounded hover:bg-gray-200 duration-500">Home</p>
                </a>
            </li>
            <li class="mx-2 my-5 nav:my-0" id="categoryDropdown">
                <p class="text-xl cursor-pointer duration-500 px-2 py-1 rounded hover:bg-gray-200">Category</p>
                <ul class="absolute z-50 text-[13px] rounded hidden mt-2 p-5 bg-white shadow" id="categoryMenu">
                    <a href="<?php echo e(route('user.kategori1')); ?>">
                        <li class="p-3 rounded hover:bg-gray-200">HERBS PRODUCTS</li>
                    </a>
                    <a href="<?php echo e(route('user.kategori2')); ?>">
                        <li class="p-3 rounded hover:bg-gray-200">COSMETICS & HOME CARE</li>
                    </a>
                    <a href="<?php echo e(route('user.kategori3')); ?>">
                        <li class="p-3 rounded hover:bg-gray-200">HEALTH FOOD & BEVERAGES</li>
                    </a>
                </ul>
                
            </li>
            <li class="mx-2 my-5 nav:my-0">
                <a href="https://wasap.at/mNsK61" class="text-xl duration-500" target="_blank">
                    <p class="px-2 py-1 rounded hover:bg-gray-200 duration-500">Contact</p>
                </a>
            </li>
            <li class="mx-2 my-5 nav:my-0">
                <form class="flex items-center" action="<?php echo e(url('/')); ?>">
                    <input name="keyword" type="text" value="<?php echo e(Request::get('keyword')); ?>" placeholder="Search" class="border-2 hover:border-sky-700 p-1 rounded-md">
                    <span class="text-xl font-weight-bold cursor-pointer ml-3">
                        <button type="submit">
                            <ion-icon class="mb-[-2px]" name="search"></ion-icon>
                        </button>
                    </span>
                </form>
            </li>
        </ul>
    </nav>

    
    <?php echo $__env->yieldContent('container'); ?>

</body>

<script>
    // punya bleh
    let btn = document.getElementById('menuBtn');
    let list = document.getElementById('menuItem');

    btn.addEventListener('click', function() {
        btn.name === 'menu' ? btn.name = "close" : btn.name = "menu";
        list.classList.toggle('top-[60px]');
        list.classList.toggle('opacity-100');
        list.classList.toggle('shadow');
    });

    // punya gw
    // function Menu(e) {
    //     let list = document.querySelector('ul');
    //     e.name === 'menu' ? 
    //     (e.name = "close", list.classList.add('top-[80px]'), list.classList.add('opacity-100'), list.classList.add('shadow')) : 
    //     (e.name = "menu", list.classList.remove('top-[80px]'), list.classList.remove('opacity-100'))
    // }


    // Get the category dropdown elements
    var categoryDropdown = document.getElementById('categoryDropdown');
    var categoryMenu = document.getElementById('categoryMenu');

    // Toggle visibility of the category menu on click
    categoryDropdown.addEventListener('click', function() {
        categoryMenu.classList.toggle('hidden');
    });


    // Function to toggle modal visibility
    function toggleModal(productId) {
        const modal = document.getElementById('modal' + productId);
        modal.classList.toggle('hidden');
    }
</script>

</html>
<?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/layouts/main.blade.php ENDPATH**/ ?>