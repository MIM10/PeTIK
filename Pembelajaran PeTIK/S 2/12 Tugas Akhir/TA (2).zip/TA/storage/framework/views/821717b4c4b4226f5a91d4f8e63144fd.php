<div class="preloader flex-column justify-content-center align-items-center">

    
    <img src="<?php echo e(asset(config('adminlte.preloader.img.path', 'vendor/adminlte/dist/img/AdminLTELogo.png'))); ?>"
         class="<?php echo e(config('adminlte.preloader.img.effect', 'animation__shake')); ?>"
         alt="<?php echo e(config('adminlte.preloader.img.alt', 'AdminLTE Preloader Image')); ?>"
         width="<?php echo e(config('adminlte.preloader.img.width', 60)); ?>"
         height="<?php echo e(config('adminlte.preloader.img.height', 60)); ?>">

</div>
<?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/vendor/adminlte/partials/common/preloader.blade.php ENDPATH**/ ?>