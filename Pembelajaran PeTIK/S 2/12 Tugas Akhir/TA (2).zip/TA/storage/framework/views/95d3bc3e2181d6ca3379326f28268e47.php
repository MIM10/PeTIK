
<?php $__env->startSection('title', 'Data Populer'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Data Populer</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php
        $ar_judul = ['No', 'Nama', 'Harga', 'Stok', 'Kategori', 'Action'];
        $no = 1;
    ?>
    <a class="btn btn-primary btn-md" href="<?php echo e(route('populer.create')); ?>" role="button">Tambah Populer</a>
    <br /><br />

    <form action="<?php echo e(route('populer.index')); ?>">
        <div class="input-group">
            <input name="keyword" type="text" value="<?php echo e(Request::get('keyword')); ?>" class="form-control">
            <div class="input-group-append">
                <input type="submit" value="Filter" class="btn btn-primary">
            </div>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($jdl); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $ar_carousel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($i->nama); ?></td>
                    <td><?php echo e($i->harga); ?></td>
                    <td><?php echo e($i->stok); ?></td>
                    <td><?php echo e($i->kategori); ?></td>
                    <td>
                        <form action="<?php echo e(route('populer.destroy', $i->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?> 
                            <?php echo method_field('delete'); ?> 
                            <a class="btn btn-info" href="<?php echo e(route('populer.show', $i->id)); ?>"><i class="fas fa-fw fa-eye"></i></a>
                            <a class="btn btn-success" href="<?php echo e(route('populer.edit', $i->id)); ?>"><i class="fas fa-fw fa-pen"></i></a>
                            <button class="btn btn-danger" onclick="return confirm('Anda Yakin Data di Hapus?')"><i class="fas fa-fw fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($ar_carousel->links()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/populer/index.blade.php ENDPATH**/ ?>