
<?php $__env->startSection('title', 'Edit Populer'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Edit Data Populer</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <a class="btn btn-secondary btn-md" href="<?php echo e('/populer'); ?>" role="button">Back</a><br /><br />
    
    
    <?php
        $rs1 = App\Models\Carousel::all();
    ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('populer.update', $rs->id)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo csrf_field(); ?> 
    <?php echo method_field('put'); ?> 
    <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" value="<?php echo e($rs->nama); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Kegunaan</label>
        <input type="text" name="kegunaan" value="<?php echo e($rs->kegunaan); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Harga</label>
        <input type="text" name="harga" value="<?php echo e($rs->harga); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Stok</label>
        <input type="text" name="stok" value="<?php echo e($rs->stok); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>ID Kategori</label>
        <input type="text" name="idkategori" value="<?php echo e($rs->idkategori); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Komposisi</label>
        <input type="text" name="komposisi" value="<?php echo e($rs->komposisi); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Kontra Indikasi</label>
        <input type="text" name="kontra_indikasi" value="<?php echo e($rs->kontra_indikasi); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Aturan Pakai</label>
        <input type="text" name="aturan_pakai" value="<?php echo e($rs->aturan_pakai); ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label>Foto</label>
        <input type="text" name="foto" value="<?php echo e($rs->foto); ?>" class="form-control" />
    </div>
    <button type="submit" class="btn btn-primary" name="proses">Ubah</button>

    <button type="reset" class="btn btn-warning" name="unproses">Batal</button>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/populer/form_edit.blade.php ENDPATH**/ ?>