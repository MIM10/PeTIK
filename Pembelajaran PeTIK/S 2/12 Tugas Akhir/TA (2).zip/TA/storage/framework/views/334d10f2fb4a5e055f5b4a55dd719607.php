
<?php $__env->startSection('title', 'Detail Populer'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Detail Populer</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php $__currentLoopData = $ar_carousel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-3" style="max-width: 25rem;">
            <?php
                if(!empty($i->foto)){
                ?>
                    <img src="<?php echo e(asset($i->foto)); ?>" alt="<?php echo e($i->nama); ?>" width="" class="card-img-top mr-3 shadow-sm">
                <?php    
                }
            ?>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-4">
                    <h5 class="card-title"><strong><?php echo e($i->nama); ?></strong></h5>
                    <h5 class="card-title"><?php echo e($i->harga); ?></h5>
                </div>
                <p class="card-text"><?php echo e($i->kegunaan); ?></p>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">
                    <div class="d-flex justify-content-between">
                        <div>
                            <div>
                                <strong>Kategori</strong>
                            </div>
                            <div class="d-flex justify-content-center">
                                <?php echo e($i->kategori); ?>

                            </div>
                        </div>
                        <div>
                            <div>
                                <strong>Stok</strong>
                            </div>
                            <div class="d-flex justify-content-center">
                                <?php echo e($i->stok); ?>

                            </div>
                        </div>
                    </div>
                </li>
                <li class="list-group-item"><strong>Komposisi</strong> <br> <?php echo e($i->komposisi); ?></li>
                <li class="list-group-item"><strong>Kontra Indikasi</strong> <br> <?php echo e($i->kontra_indikasi); ?></li>
                <li class="list-group-item"><strong>Aturan Pakai</strong> <br> <?php echo e($i->aturan_pakai); ?></li>
            </ul>
            <div class="card-body d-flex justify-content-center p-0 py-3">
                <form action="<?php echo e(route('populer.destroy', $i->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('delete'); ?> 
                    <a href="<?php echo e(url('/populer')); ?>" class="btn btn-info">
                        <i class="fas fa-fw fa-arrow-left"></i>
                    </a>
                    <a class="btn btn-success" href="<?php echo e(route('populer.edit', $i->id)); ?>">
                        <i class="fas fa-fw fa-pen"></i>
                    </a>
                    <button class="btn btn-danger" onclick="return confirm('Anda Yakin Data di Hapus?')">
                        <i class="fas fa-fw fa-trash"></i>
                    </button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/populer/show.blade.php ENDPATH**/ ?>