<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HNI Hpai</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body>
    
    <nav class="flex flex-row mb-5 px-4 bg-white justify-between h-16 shadow-md">
        <div class="flex gap-5 items-center font-bold">
            <img class="h-12 " src="<?php echo e(asset('/img/Logo-HNI.png')); ?>" alt="Logo">
            <a href="#">Katalog HNI</a>
        </div>
        <div class="md:flex md:items-center md:gap-12 flex justify-center">
            <nav aria-label="Site Nav" class="hidden md:block">
                <ul class="flex items-center gap-6 text-sm">
                    <li>
                        <a class="text-gray-500 transition hover:text-gray-500/75" href="/">A-Z List</a>
                    </li>
                    <li>
                        <button id="dropdownNavbarLink" data-dropdown-toggle="dropdownNavbar"
                            class="flex text-gray-500 transition hover:text-gray-500/75" href="/">Category
                            <svg class="w-5 h-5 ml-1" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </button>

                        
                        <div id="dropdownNavbar"
                            class="z-10 hidden font-normal bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700 dark:divide-gray-600">
                            <ul class="py-2 text-sm text-gray-700 dark:text-gray-400"
                                aria-labelledby="dropdownLargeButton">
                                <li>
                                    <a href="#"
                                        class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dashboard</a>
                                </li>
                                <li>
                                    <a href="#"
                                        class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dashboard</a>
                                </li>
                                <li>
                                    <a href="#"
                                        class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dashboard</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="">
                        <input class="border-2 hover:border-sky-700 p-1 rounded-md" placeholder="Search" type="text">
                    </li>
                </ul>
            </nav>

            <div class="flex items-center gap-4">
                <div class="block md:hidden">
                    <button class="rounded bg-gray-100 p-2 text-gray-600 transition hover:text-gray-600/75">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>


    <div class="container">
        
        <div
            class="grid justify-items-center p-3 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 xl:grid-cols-5 h-fit max-w-7xl gap-4 bg-slate-300 ">
            <table class="table table-striped">
                
                <tbody>
                    <?php $__currentLoopData = $ar_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="">
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($i->nama); ?></td>
                            <td><?php echo e($i->harga); ?></td>
                            <td><?php echo e($i->stok); ?></td>
                            <td><?php echo e($i->kategori); ?></td>
                            <td>
                                <form action="<?php echo e(route('produk.destroy', $i->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> 
                                    <?php echo method_field('delete'); ?> 
                                    <a class="btn btn-info" href="<?php echo e(route('produk.show', $i->id)); ?>"><i
                                            class="fas fa-fw fa-eye"></i></a>
                                    <a class="btn btn-success" href="<?php echo e(route('produk.edit', $i->id)); ?>"><i
                                            class="fas fa-fw fa-pen"></i></a>
                                    <button class="btn btn-danger"
                                        onclick="return confirm('Anda Yakin Data di Hapus?')"><i
                                            class="fas fa-fw fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
<?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/forUser/index.blade.php ENDPATH**/ ?>