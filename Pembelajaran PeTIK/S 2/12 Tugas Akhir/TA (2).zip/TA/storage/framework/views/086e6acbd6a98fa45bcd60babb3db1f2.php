
<?php $__env->startSection('title', 'Form Produk'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Input Data Produk</h1><br />
    <a class="btn btn-secondary btn-md" href="<?php echo e('/produk'); ?>" role="button">Back</a><br /><br />
    <table class="table table-striped">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        
        
        <?php
            $rs1 = App\Models\Produk::all();
        ?>
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('produk.store')); ?>">
            <?php echo csrf_field(); ?> 

            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control" />
                <label class="mt-sm-3">Deskripsi</label>
                <input type="text" name="desc" class="form-control" />
                <label class="mt-sm-3">Harga</label>
                <input type="text" name="harga" class="form-control" />
                <label class="mt-sm-3">Stok</label>
                <input type="text" name="stok" class="form-control" />
                <label class="mt-sm-3">Kategori</label>
                <input type="text" name="idkategori" class="form-control" />
                <label class="mt-sm-3">Kegunaan</label>
                <input type="text" name="kegunaan" class="form-control" />
                <label class="mt-sm-3">Komposisi</label>
                <input type="text" name="komposisi" class="form-control" />
                <label class="mt-sm-3">Kontra Indikasi</label>
                <input type="text" name="kontra_indikasi" class="form-control" />
                <label class="mt-sm-3">Aturan Pakai</label>
                <input type="text" name="aturan_pakai" class="form-control" />
                <label class="mt-sm-3">Foto</label>
                <input type="file" class="form-control p-1" name="image">
            </div>

            <button type="submit" class="btn btn-primary" name="proses">Simpan</button>

            <button type="reset" class="btn btn-warning" name="unproses">Batal</button>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('css'); ?>
            <link rel="stylesheet" href="/css/admin_custom.css">
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
            <script>
                console.log('Hi!');
            </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/produk/form.blade.php ENDPATH**/ ?>