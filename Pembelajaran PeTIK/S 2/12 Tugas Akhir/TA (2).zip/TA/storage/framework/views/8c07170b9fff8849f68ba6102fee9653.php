

<?php $__env->startSection('title', 'HNI Catalog'); ?>
<?php $__env->startSection('container'); ?>
    
    
    <div class="flex flex-wrap mt-10 hpK:mx-3 hpG:mx-5 tablet:mx-10 laptop:mx-32 desktop:mx-60 justify-center bg-white gap-3">
        
        <?php $__currentLoopData = $ar_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div onclick="toggleModal('<?php echo e($i->id); ?>')" class="flex flex-col py-3 rounded hover:bg-gray-200 duration-300 cursor-pointer shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] bg-white ">
                <div class="mb-2 mx-3 rounded shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] hp:w-28 ">
                    <img src="<?php echo e(asset($i->foto)); ?>" alt="<?php echo e($i->nama); ?>" class="min-h-[100px] max-h-[150px] my-2">
                </div>
                <div class="flex flex-col mx-4">
                    <div class="mb-10">
                        <p class="text-[13px]"><?php echo e($i->nama); ?></p>
                    </div>
                    <div class="flex flex-row justify-between">
                        <p class="text-[12px] font-extralight text-gray-500">Rp. <?php echo e($i->harga); ?></p>
                        <p class="text-[12px] font-extralight text-gray-500">Stok : <?php echo e($i->stok); ?></p>
                    </div>
                </div>
            </div>

            
            <div id="modal<?php echo e($i->id); ?>" class="hidden fixed inset-0 flex items-center justify-center z-50">
                
                <div class="flex flex-col justify-content-center bg-white hpK:w-72 shadow-[0px_0px_3px_3px_rgba(0,0,0,0.10)] rounded-lg p-6 max-w-md">
                    <div class="flex">
                        
                        <div class="text-2xl items-center cursor-pointer mr-2" onclick="toggleModal('<?php echo e($i->id); ?>')">
                            <ion-icon class="hover:bg-gray-200 duration-200" name="close" id="menuBtn"></ion-icon>
                        </div>
                        <h2 class="text-xl flex text-center font-semibold mt-[-1px] mb-4">Product Details</h2>
                    </div>
                    <div class="mb-5 flex rounded justify-center shadow-[0px_0px_1px_1px_rgba(0,0,0,0.10)] hp:w-28 ">
                        <img src="<?php echo e(asset($i->foto)); ?>" alt="<?php echo e($i->nama); ?>" class="min-h-[100px] max-h-[150px] my-7">
                    </div>
                    <div>
                        <p class="mb-1 font-semibold"><?php echo e($i->nama); ?></p>
                        <div class="flex text-[12px] mb-5 font-extralight text-gray-500">
                            <p class="mr-2">Rp. <?php echo e($i->harga); ?></p>
                            <p class="ml-2">Stok : <?php echo e($i->stok); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-semibold">Kegunaan</p>
                            <p class="text-[12px] mb-5 font-normal"><?php echo e($i->kegunaan); ?></p>
                            <p class="text-sm font-semibold">Komposisi</p>
                            <p class="text-[12px] mb-5 font-normal"><?php echo e($i->komposisi); ?></p>
                            <p class="text-sm font-semibold">Aturan Pakai</p>
                            <p class="text-[12px] mb-2 font-normal"><?php echo e($i->aturan_pakai); ?></p>
                        </div>
                    </div>
                    <!-- Add more details here if needed -->
                    <a href="https://api.whatsapp.com/send?phone=+6285772396815&text=Assalamualaikum%20saya%20mau%20pesan%20%3A%0A*<?php echo e($i->nama); ?>*%0ANama%20%3A%20...%0AJumlah%20%3A%20...%0AAlamat%20%3A%20..." target="_blank">
                        <div class="bg-gray-300 hover:bg-gray-400 duration-300 px-4 py-2 rounded-lg mt-4 cursor-pointer text-center">
                            Buy 
                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Folder Mu'aadz\PeTIK\Pembelajaran PeTIK\S 2\12 Tugas Akhir\TA\resources\views/user/kategori2.blade.php ENDPATH**/ ?>