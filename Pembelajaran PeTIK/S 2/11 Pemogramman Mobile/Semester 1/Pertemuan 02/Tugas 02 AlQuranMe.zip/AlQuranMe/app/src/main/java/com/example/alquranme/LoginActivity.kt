package com.example.alquranme

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        supportActionBar?.hide()

        var username: EditText = findViewById(R.id.inputan_username)
        var password: EditText = findViewById(R.id.inputan_password)
        var btn: Button = findViewById(R.id.button)

        btn.setOnClickListener { actionLogin(username.text.toString(), password.text.toString()) }
    }

    fun actionLogin(username: String, password: String) {
        if (username == "Adzna" && password == "adzna123") {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            Toast.makeText(this, "Gagal Login", Toast.LENGTH_SHORT).show()
        }
    }
}