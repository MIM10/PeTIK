package com.example.utsandroid

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TableLayout
import android.widget.TextView

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        supportActionBar?.hide()

        val btn_back: ImageView = findViewById(R.id.backToOnBoarding)
        val to_signup: TextView = findViewById(R.id.text_to_signup)

        btn_back.setOnClickListener { intentToBoarding() }
        to_signup.setOnClickListener { intentToSignup() }
    }

    fun intentToBoarding() {
        startActivity(Intent(this, onBoardingActivity::class.java))
        finish()
    }

    fun intentToSignup() {
        startActivity(Intent(this, SignupActivity::class.java))
        finish()
    }
}