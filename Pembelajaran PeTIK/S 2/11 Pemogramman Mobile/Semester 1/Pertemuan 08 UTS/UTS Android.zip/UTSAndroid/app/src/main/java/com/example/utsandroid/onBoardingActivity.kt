package com.example.utsandroid

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TableLayout

class onBoardingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_boarding)

        supportActionBar?.hide()

//        val btn_getStarted: TableLayout = findViewById(R.id.btn_getStarted)
        val btn_signin: TableLayout = findViewById(R.id.btn_sign_in)

//        btn_getStarted.setOnClickListener { intentToLogin() }
        btn_signin.setOnClickListener { intentToLogin() }
    }

    fun intentToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
    }
}