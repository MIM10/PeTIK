package com.example.utsandroid

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class SignupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        supportActionBar?.hide()

        val to_signin: TextView = findViewById(R.id.text_to_signin)
        val back_to_login: ImageView = findViewById(R.id.backLogin)

        to_signin.setOnClickListener { intentToSignin() }
        back_to_login.setOnClickListener { intentToSignin() }
    }

    fun intentToSignin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}