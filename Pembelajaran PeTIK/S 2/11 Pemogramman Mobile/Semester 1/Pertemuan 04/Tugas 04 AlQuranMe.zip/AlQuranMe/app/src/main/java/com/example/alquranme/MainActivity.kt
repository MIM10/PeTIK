package com.example.alquranme

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        var btn: Button = findViewById(R.id.button2)

        btn.setOnClickListener { actionLogin() }
    }

    fun actionLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}