package com.example.kopimantan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        supportActionBar?.hide()

        var back: TextView = findViewById(R.id.backToLogin)
        var submitRegister: Button = findViewById(R.id.submitRegister)

        submitRegister.setOnClickListener { alert() }
        back.setOnClickListener { back() }
    }

    fun alert() {
        Toast.makeText(this, "Dalam Masa Pengembangan", Toast.LENGTH_SHORT).show()
    }

    fun back() {
        startActivity(Intent(this, LoginActivity::class.java))
    }
}