package com.example.quranapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailAdapterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_adapter)
    }
}