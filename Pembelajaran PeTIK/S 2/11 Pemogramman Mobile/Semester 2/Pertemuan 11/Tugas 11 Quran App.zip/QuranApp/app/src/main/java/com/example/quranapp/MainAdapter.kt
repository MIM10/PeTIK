package com.example.quranapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.quranapp.data.DataItem

class MainAdapter(private val listQuran: ArrayList<DataItem>): RecyclerView.Adapter<MainAdapter.ListViewHolder>() {
    class ListViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val namaSurahArab : TextView = itemView.findViewById(R.id.it_tv_surahArab)
        private val namaSurah : TextView = itemView.findViewById(R.id.it_tv_surah)
        private val tmptTurun : TextView = itemView.findViewById(R.id.it_tv_tmptTurun)
        private val arti : TextView = itemView.findViewById(R.id.it_tv_arti)
        fun binding(quran: DataItem) {
            namaSurah.text = quran.namaLatin
            namaSurahArab.text = quran.nama
            tmptTurun.text = quran.tempatTurun
            arti.text = quran.jumlahAyat.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        return MainAdapter.ListViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_quran, parent, false)
        )
    }

    override fun getItemCount(): Int = listQuran.size


    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val data = listQuran[position]
        holder.binding(data)
    }
}