package com.example.quranapp.data

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class QuranResponse(

    @field:SerializedName("code")
    val code: Int? = null,

    @field:SerializedName("data")
    val data: List<DataItem>? = null,

    @field:SerializedName("message")
    val message: String? = null
) : Parcelable

@Parcelize
data class AudioFull(

    @field:SerializedName("01")
    val jsonMember01: String? = null,

    @field:SerializedName("02")
    val jsonMember02: String? = null,

    @field:SerializedName("03")
    val jsonMember03: String? = null,

    @field:SerializedName("04")
    val jsonMember04: String? = null,

    @field:SerializedName("05")
    val jsonMember05: String? = null
) : Parcelable

@Parcelize
data class DataItem(

    @field:SerializedName("jumlahAyat")
    val jumlahAyat: Int? = null,

    @field:SerializedName("nama")
    val nama: String? = null,

    @field:SerializedName("audioFull")
    val audioFull: AudioFull? = null,

    @field:SerializedName("tempatTurun")
    val tempatTurun: String? = null,

    @field:SerializedName("arti")
    val arti: String? = null,

    @field:SerializedName("deskripsi")
    val deskripsi: String? = null,

    @field:SerializedName("nomor")
    val nomor: Int? = null,

    @field:SerializedName("namaLatin")
    val namaLatin: String? = null
) : Parcelable