package com.example.tugas09

import android.content.Context

class DataUser(context: Context) {
    companion object {
        private  val PREF_NAME = "data_user"
        private  val NAME = "name_user"
        private  val NOTE  = "note_user"
    }
    private val preferences= context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    fun setlUser(name: String, note: String) {
        val editUser = preferences.edit()
        editUser.putString(NAME, name)
        editUser.putString(NOTE, note)
        editUser.apply()
    }
    fun setUser(name: String, note: String) {
        val editUser = preferences.edit()
        editUser.putString(NAME, name)
        editUser.putString(NOTE, note)
        editUser.apply()
    }

    fun getUser(): UserResponse {
        val userData = UserResponse()
        userData.name = preferences.getString(NAME, "")
        userData.note = preferences.getString(NOTE, "")
        return userData

    }
}