package com.example.tugas09

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class UserResponse(
    var name: String? = null,
    var note: String? = null
): Parcelable