package com.example.tugas09

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tugas09.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private  lateinit var dataUser: DataUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        dataUser = DataUser(this)
        val data = dataUser.getUser()
        binding.tvName.text = data.name
        binding.tvNote.text = data.note

        binding.btnSubmit.setOnClickListener{ submitData()}
    }

    fun submitData(){
        val name = binding.etName.text.toString()
        val note = binding.etNote.text.toString()

        dataUser.setUser(name, note)

        val user = dataUser.getUser()
        binding.tvName.text = user.name
        binding.tvNote.text = user.note

    }

}